#ifndef TURNS_H
#define TURNS_H

#include <Arduino.h>

void detectAndHandleTurns(); // called from main loop

#endif
